

library(shiny)

# Define UI for application that draws a histogram
ui <- fluidPage(
  

  tags$h1("Endometriosis Risk Calculator",
          style = "color:black; text-align: center;"),
  
  tags$h4("Designed by University of Rochester iGEM Team Uterus 2020",
          style = "color:black; text-align: center;"),
  
  tags$hr(),
  

  
  
  wellPanel(
    
    fluidRow(
      column(7,
             tags$h4(tags$strong("Introduction"),style = "color:black"),
             
             
             tags$h5("· Endometriosis is a chronic disease where endometrial-like tissue 
            (similar to the type that lines your uterus) grows outside of the 
            uterus and other organs in your abdomen, and causes inflammation, 
            scarring, damage to nearby structures, intense pain, 
            and even infertility (Zondervan et al., 2018).", 
                     style = "color:black; line-height: 1.5"),
             
             tags$h5("· Endometriosis affects 1 in 10 menstruating people. This software 
            aims to predict your risk of having endometriosis based on 42 variables.",
                     style = "color:black; line-height: 1.5"),
             
             tags$h5("· To use the software, please complete the questionnaire and 
            click the “Run Prediction” button.",
                     style = "color:black; line-height: 1.5")),
      column(5, tags$img(height = 255, width = 330, src = "Endometriosis.png"))
    ),
    
  ),
  
  wellPanel(
    
    tags$h4(tags$strong("Questionnaire"),style = "color:black"),
    
    tags$h5("· You need to answer all questions to run the prediction; 
            you will get a NA result if you have unanswered questions. 
            Please select “No Answer” if you do not want to answer",
            style = "color:black; line-height: 1.5"),
    
    tags$h5("· Questions 5-9 and 11: for post menopausal women, 
            please answer based on your menstrual history to the best of your memory.",
            style = "color:black; line-height: 1.5"),
    
    tags$h5("· Question 27-42: please select “No” if you have no answer.",
            style = "color:black; line-height: 1.5"),
    
    tags$h5("· The information you filled is NOT stored anywhere,
            and the tool will keep your identity anonymous.",
            style = "color:black; line-height: 1.5"),
    
    
    
    tags$br(),
    
    numericInput(inputId = "age", 
                 label = "1. What is your age? (Enter 98 if you do not want to answer)", 
                 value = 0, min = NA, max = NA, step = NA, width = NULL),
    
    selectInput(inputId = "Civil_Status", 
                label = "2. What is your civil status?", 
                choices = c(" " = 999, "Single"= 1 ,"Married" = 2, "Consensual" = 3,"Divorced" = 4,"Widowed" = 5,"No Answer" = 98), 
                selected = " ", multiple = FALSE, selectize = TRUE, width = NULL, size = NULL),
    
    selectInput(inputId = "Education", 
                label = "3. What is your highest level of education?", 
                choices = c(" " = 999, "High School"= 1 ,"1 year of college" = 2, 
                            "2 years college/technical degree" = 3,"3 years College" = 4,"Bachelor's" = 5,
                            "Some masters courses" = 6, "Masters" = 7,"Some Doctorate Course" = 8,"Doctorate" = 9, "No Answer" = 98), 
                selected = " ", multiple = FALSE,selectize = TRUE, width = NULL, size = NULL),
    
    numericInput(inputId = "age_menarche", 
                 label = "4. What is your age of the first period? (Enter 98 if you do not want to answer)", 
                 value = 0, min = NA, max = NA, step = NA, width = NULL),
    
    selectInput(inputId = "cycle_regularity", 
                label = "5. Is your menstrual cycle regular?", 
                choices = c(" " = 999, "No" = 0, "Yes"= 1 , "No Answer" = 98), 
                selected = " ", multiple = FALSE, selectize = TRUE, width = NULL, size = NULL),
    
    numericInput(inputId = "Menstrual_Cycle_length", 
                 label = "6. How long is your menstrual cycle in number of days 
                 (counted from the first day of one period to the first day of the next)? 
                 (Enter 98 if you do not want to answer)", 
                 value = 0, min = NA, max = NA, step = NA, width = NULL),
    
    numericInput(inputId = "Period_length", 
                 label = "7. How long is your period in number of days? 
                 (Enter 98 if you do not want to answer)", 
                 value = 0, min = NA, max = NA, step = NA, width = NULL),
    
    selectInput(inputId = "Dysmenorrhea", 
                label = "8. Do you have Dysmenorrhea 
                (abdomen, back, or thighs pain with menstruation)?", 
                choices = c(" " = 999, "No" = 0, "Yes"= 1 , "No Answer" = 98),
                selected = " ", multiple = FALSE, selectize = TRUE, width = NULL, size = NULL),
    
    selectInput(inputId = "Incapacitating_pain", 
                label = "9. Do you experience incapacitating pain 
                (pains that makes you unable to work or do things normally) 
                during your period?", 
                choices = c(" " = 999, "No" = 0, "Yes"= 1 , "No Answer" = 98),
                selected = " ", multiple = FALSE, selectize = TRUE, width = NULL, size = NULL),
    
    selectInput(inputId = "Dyspareunia", 
                label = "10. Do you have Dyspareunia (pain during intercourse)?", 
                choices = c(" " = 999, "No" = 0, "Yes"= 1 , "No Answer" = 98),
                selected = " ", multiple = FALSE, selectize = TRUE, width = NULL, size = NULL),
    
    selectInput(inputId = "problems_getting_pregant", 
                label = "11. Do you have problems getting pregant? 
                (Please answer No Answer if you have never tried to get pregnant)", 
                choices = c(" " = 999, "No" = 0, "Yes"= 1 , "No Answer" = 98),
                selected = " ", multiple = FALSE, selectize = TRUE, width = NULL, size = NULL),
    
    selectInput(inputId = "children_n", 
                label = "12. How many (biological) children do you have?", 
                choices = c(" " = 999, "0" = 0, "1"= 1 , "2" = 2, "3"= 4 ,
                            "4" = 4, "5"= 5 ,"6" = 6, "7"= 7 ,"8" = 8, "≥ 9"= 9 ,
                            "No Answer" = 98),
                selected = " ", multiple = FALSE, selectize = TRUE, width = NULL, size = NULL),
    
    selectInput(inputId = "miscarriages_n", 
                label = "13. How many time have you experienced miscarriages?", 
                choices = c(" " = 999, "0" = 0, "1"= 1 , "2" = 2, "3"= 4 ,
                            "4" = 4, "5"= 5 ,"≥6" = 6, "No Answer" = 98),
                selected = " ", multiple = FALSE, selectize = TRUE, width = NULL, size = NULL),
    
    numericInput(inputId = "age_1st_child", 
                 label = "14. What was your age of having the first child? 
                 (Enter 98 if you do not have child or you do not want to answer)", 
                 value = 0, min = NA, max = NA, step = NA, width = NULL),
    
    selectInput(inputId = "OCP_before", 
                label = "15. Have you taken oral contraceptives before?", 
                choices = c(" " = 999, "No" = 0, "Yes"= 1 , "No Answer" = 98),
                selected = " ", multiple = FALSE, selectize = TRUE, width = NULL, size = NULL),
    
    selectInput(inputId = "BPS_tube_ligation", 
                label = "16. Do you have tube ligation 
                (having your tubes tied for birth control)?", 
                choices = c(" " = 999, "No" = 0, "Yes"= 1 , "No Answer" = 98),
                selected = " ", multiple = FALSE, selectize = TRUE, width = NULL, size = NULL),
    
    selectInput(inputId = "Smoking", 
                label = "17. Do you smoke?", 
                choices = c(" " = 999, "No" = 0, "Yes"= 1 , "No Answer" = 98),
                selected = " ", multiple = FALSE, selectize = TRUE, width = NULL, size = NULL),
    
    selectInput(inputId = "Uterine_Fibroids", 
                label = "18. Do you have uterine fibroids 
                (benign non-concer growths that develop from the muscle tissue of the uterus)?", 
                choices = c(" " = 999, "No" = 0, "Yes"= 1 , "No Answer" = 98),
                selected = " ", multiple = FALSE, selectize = TRUE, width = NULL, size = NULL),
    
    selectInput(inputId = "Ovarian_cysts", 
                label = "19. Do you have ovarian cysts 
                (fluid-filled sacs or pockets in an ovary or on its surface)?", 
                choices = c(" " = 999, "No" = 0, "Yes"= 1 , "No Answer" = 98),
                selected = " ", multiple = FALSE, selectize = TRUE, width = NULL, size = NULL),    
    
    selectInput(inputId = "Constipation", 
                label = "20. Do you have chronic constipation?", 
                choices = c(" " = 999, "No" = 0, "Yes"= 1 , "No Answer" = 98),
                selected = " ", multiple = FALSE, selectize = TRUE, width = NULL, size = NULL),  
    
    selectInput(inputId = "Abnormal_PAP", 
                label = "21. Do you have an abnormal PAP test result? 
                (Please select No Answer if you have never had an PAP test)", 
                choices = c(" " = 999, "No" = 0, "Yes"= 1 , "No Answer" = 98),
                selected = " ", multiple = FALSE, selectize = TRUE, width = NULL, size = NULL),
    
    selectInput(inputId = "Breast_cysts", 
                label = "22. Do you have breast cysts?", 
                choices = c(" " = 999, "No" = 0, "Yes"= 1 , "No Answer" = 98),
                selected = " ", multiple = FALSE, selectize = TRUE, width = NULL, size = NULL),
    
    selectInput(inputId = "GYN_infecctions", 
                label = "23. Do you have reproductive tract infections?", 
                choices = c(" " = 999, "No" = 0, "Yes"= 1 , "No Answer" = 98),
                selected = " ", multiple = FALSE, selectize = TRUE, width = NULL, size = NULL),
    
    selectInput(inputId = "Pelvic_Pain", 
                label = "24. Do you have pelvic pain?", 
                choices = c(" " = 999, "No" = 0, "Yes"= 1 , "No Answer" = 98),
                selected = " ", multiple = FALSE, selectize = TRUE, width = NULL, size = NULL),
    
    selectInput(inputId = "AUB", 
                label = "25. Do you have abnormal uterine bleeding?", 
                choices = c(" " = 999, "No" = 0, "Yes"= 1 , "No Answer" = 98),
                selected = " ", multiple = FALSE, selectize = TRUE, width = NULL, size = NULL),
    
    selectInput(inputId = "Family_Hx", 
                label = "26. Do you have family history of endometriosis?", 
                choices = c(" " = 999, "No" = 0, "Yes"= 1 , "No Answer" = 98),
                selected = " ", multiple = FALSE, selectize = TRUE, width = NULL, size = NULL),
    
    selectInput(inputId = "allerg", 
                label = "27. Do you have allergies?", 
                choices = c(" " = 999, "No" = 0, "Yes"= 1),
                selected = " ", multiple = FALSE, selectize = TRUE, width = NULL, size = NULL),
    
    selectInput(inputId = "diabetes", 
                label = "28. Do you have diabetes?", 
                choices = c(" " = 999, "No" = 0, "Yes"= 1),
                selected = " ", multiple = FALSE, selectize = TRUE, width = NULL, size = NULL),
    
    selectInput(inputId = "leg", 
                label = "29. Do you have leg pain?", 
                choices = c(" " = 999, "No" = 0, "Yes"= 1),
                selected = " ", multiple = FALSE, selectize = TRUE, width = NULL, size = NULL),
    
    selectInput(inputId = "infertility", 
                label = "30. Do you have infertility?", 
                choices = c(" " = 999, "No" = 0, "Yes"= 1),
                selected = " ", multiple = FALSE, selectize = TRUE, width = NULL, size = NULL),
    
    selectInput(inputId = "asymptomatic", 
                label = "31. Are you asymptomatic (showing no symptoms of 
                severe pain, bloating, constipation. diarrhea, and heavy bleeding)?", 
                choices = c(" " = 999, "No" = 0, "Yes"= 1),
                selected = " ", multiple = FALSE, selectize = TRUE, width = NULL, size = NULL),
    
    selectInput(inputId = "dizziness", 
                label = "32. Do you have dizziness?", 
                choices = c(" " = 999, "No" = 0, "Yes"= 1),
                selected = " ", multiple = FALSE, selectize = TRUE, width = NULL, size = NULL),
    
    selectInput(inputId = "insomnia", 
                label = "33. Do you have chronic insomnia?", 
                choices = c(" " = 999, "No" = 0, "Yes"= 1),
                selected = " ", multiple = FALSE, selectize = TRUE, width = NULL, size = NULL),
    
    selectInput(inputId = "chronic_infections", 
                label = "34. Do you have chronic infections?", 
                choices = c(" " = 999, "No" = 0, "Yes"= 1),
                selected = " ", multiple = FALSE, selectize = TRUE, width = NULL, size = NULL),
    
    selectInput(inputId = "NSAID", 
                label = "35. Do you use NSAID (ibuprofen, paracetamol, aspirin,etc)?", 
                choices = c(" " = 999, "No" = 0, "Yes"= 1),
                selected = " ", multiple = FALSE, selectize = TRUE, width = NULL, size = NULL),
    
    selectInput(inputId = "condoms", 
                label = "36. Do you use condoms during intercourse? 
                (Please select No if you never had intercourse)", 
                choices = c(" " = 999, "No" = 0, "Yes"= 1),
                selected = " ", multiple = FALSE, selectize = TRUE, width = NULL, size = NULL),
    
    selectInput(inputId = "rythm", 
                label = "37. Do you use rhythm contraceptive 
                (track your menstrual history to predict when you'll ovulate for birth control)?", 
                choices = c(" " = 999, "No" = 0, "Yes"= 1),
                selected = " ", multiple = FALSE, selectize = TRUE, width = NULL, size = NULL),
    
    selectInput(inputId = "gastrointestinal", 
                label = "38. Do you have any stomach and intestines conditions?", 
                choices = c(" " = 999, "No" = 0, "Yes"= 1),
                selected = " ", multiple = FALSE, selectize = TRUE, width = NULL, size = NULL),
    
    selectInput(inputId = "autoimmune", 
                label = "39. Do you have autoimmune disease?", 
                choices = c(" " = 999, "No" = 0, "Yes"= 1),
                selected = " ", multiple = FALSE, selectize = TRUE, width = NULL, size = NULL),
    
    selectInput(inputId = "musculoskelet", 
                label = "40. Do you have muscle and skeleton symptoms 
                (pain, weakness, stiffness, joint noises, and decreased range of motion)?", 
                choices = c(" " = 999, "No" = 0, "Yes"= 1),
                selected = " ", multiple = FALSE, selectize = TRUE, width = NULL, size = NULL),
    
    selectInput(inputId = "gynecological_pelvic", 
                label = "41. Do you have or have you ever been diagnosed or 
                treated for any reproductive health or pelvic conditions?", 
                choices = c(" " = 999, "No" = 0, "Yes"= 1),
                selected = " ", multiple = FALSE, selectize = TRUE, width = NULL, size = NULL),
    
    selectInput(inputId = "cardiovascular", 
                label = "42. Do you have or have you ever been diagnosed or 
                treated for any cardiovascular conditions?", 
                choices = c(" " = 999, "No" = 0, "Yes"= 1),
                selected = " ", multiple = FALSE, selectize = TRUE, width = NULL, size = NULL),
    
        
            actionButton(inputId = "submit", label = tags$strong("Run Prediction"))
  ),
  
 wellPanel(
   tags$h4(tags$strong("Result")),
   verbatimTextOutput("data",placeholder = TRUE)
 ),

)


# Define server logic required to draw a histogram
server <- function(input, output) {


  observeEvent(input$submit, { 
    
    library(randomForest)
    load("data/EndoModel.RData")
    load("data/test_.RData")
    
    inputdata <- c(input$age,input$Civil_Status, input$Education,input$age_menarche,input$cycle_regularity,
                   input$Menstrual_Cycle_length,input$Period_length,input$Dysmenorrhea,input$Incapacitating_pain,
                   input$Dyspareunia,input$problems_getting_pregant,input$children_n,input$miscarriages_n,
                   input$age_1st_child,input$OCP_before,input$BPS_tube_ligation,input$Smoking,
                   input$Uterine_Fibroids,input$Ovarian_cysts,input$Constipation,input$Abnormal_PAP,
                   input$Breast_cysts,input$GYN_infecctions,input$Pelvic_Pain,input$AUB,
                   input$Family_Hx,input$allerg,input$diabetes,input$leg,input$infertility,input$asymptomatic,
                   input$dizziness,input$insomnia,input$chronic_infections,input$NSAID,input$condoms,input$rythm,
                   input$gastrointestinal,input$autoimmune,input$musculoskelet,input$gynecological_pelvic,
                   input$cardiovascular)
    
    cleandata <- as.numeric(inputdata)
    
    
    test_[nrow(test_) + 1,] = cleandata
    
    predVal <- predict(EndoModel, test_, type = "class")
    
    pos <- paste( "Your result is POSITIVE.",
                  "\n",
                  "However, this does not mean you have endometriosis.", 
                  "Please consult a doctor for further advice",
                  "\n",
                  "If you want to know more infromation about endometriosis, please check the following resources:",
                  "Our Endometriosis Educational Program: https://uofrigem.wixsite.com/endoeducation",
                  "The Center for Endometroisis care: https://centerforendo.com/",
                  "Endometriosis foundation of America: https://www.endofound.org/",
                  "Endopædia: http://endopaedia.info/",
                  "Speak Endo: https://www.speakendo.com/",
                  "Facebook group: Nancy's Nook ",
                  sep = "\n")
    
    neg <- paste( "Your result is NEGATIVE.",
                  "\n",
                  "However, this does not mean you do not have endometriosis.", 
                  "Please consult a doctor for further advice",
                  "\n",
                  "If you want to know more infromation about endometriosis, please check the following resources:",
                  "Our Endometriosis Educational Program: https://uofrigem.wixsite.com/endoeducation",
                  "The Center for Endometroisis care: https://centerforendo.com/",
                  "Endometriosis foundation of America: https://www.endofound.org/",
                  "Endopædia: http://endopaedia.info/",
                  "Speak Endo: https://www.speakendo.com/",
                  "Facebook group: Nancy's Nook ",
                  sep = "\n")
  
    
    result <- ifelse(predVal==1, pos ,neg)
    
    
    output$data <- renderText({result})
  })

  
}


# Run the application 
shinyApp(ui = ui, server = server)

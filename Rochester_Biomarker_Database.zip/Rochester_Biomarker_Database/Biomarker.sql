CREATE DATABASE  IF NOT EXISTS `biomarker` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `biomarker`;
-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: 192.168.2.128    Database: biomarker
-- ------------------------------------------------------
-- Server version	5.7.31

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Biomarker`
--

DROP TABLE IF EXISTS `Biomarker`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Biomarker` (
  `id` int(10) unsigned zerofill NOT NULL AUTO_INCREMENT,
  `biomarker` varchar(100) DEFAULT NULL,
  `type` varchar(45) DEFAULT NULL,
  `if_project` varchar(45) DEFAULT NULL,
  `reason_project` varchar(1000) DEFAULT NULL,
  `sample_type` varchar(100) DEFAULT NULL,
  `reason_sample` varchar(100) DEFAULT NULL,
  `concentration` varchar(100) DEFAULT NULL,
  `doi` varchar(100) DEFAULT NULL,
  `value_type` varchar(100) DEFAULT NULL,
  `comments` varchar(1000) DEFAULT NULL,
  `contributor` varchar(100) DEFAULT NULL,
  `createdt` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Biomarker`
--

LOCK TABLES `Biomarker` WRITE;
/*!40000 ALTER TABLE `Biomarker` DISABLE KEYS */;
INSERT INTO `Biomarker` VALUES (0000000001,'PGE2','Hormone','Yes','Literature values for PGE2 were available for our chosen sample source (menstrual effluent).','Menstrual Effluent (Blood)','Has unexplored diagnostic potential and does not require invasive surgery ','55 ng/mL','﻿10.1093/humrep/des331','Threshold','Hormones may be unstable and difficult to separate.','UR iGEM 2020 Team Uterus',NULL),(0000000002,'IGFBP-1','Protein','Yes','Literature values for IGFBP-1 were available in our chosen sample source and shown to have high specificity for endometriosis.','Menstrual Effluent (Blood)','Has unexplored diagnostic potential and does not require invasive surgery ','800 ng/ 100 ug protein','﻿10.1016/j.fertnstert.2005.08.046','Threshold','Requires isolation of endometrial stromal cells from our sample source (which can take up to 72 hours) and an induction step (another 24 hours). ','UR iGEM 2020 Team Uterus',NULL),(0000000003,'PRL','Hormone','Yes','Literature values for PRL were available in our chosen sample source and shown to have specificity to endometriosis.','Menstrual Effluent (Blood)','Has unexplored diagnostic potential and does not require invasive surgery ','20 ng / 100 ug protein','﻿10.1016/j.fertnstert.2005.08.046','Threshold ','Hormones may be unstable and difficult to separate. Also requires isolation of endometrial stromal cells (which can take up to 72 hours) and an induction step (another 24 hours).','UR iGEM 2020 Team Uterus',NULL),(0000000004,'IL-6','Protein','Yes','This molecule has been named the \"interleukin of endometriosis\" and has been detected in quantifiable levels in our selected sample.','Menstrual Effluent (Blood)','Has unexplored diagnostic potential and does not require invasive surgery ','8968 pg/mL','﻿10.1016/j.fertnstert.2013.09.041','Threshold','Interleukins are very broad response molecules and may not exhibit high specificy alone.','UR iGEM 2020 Team Uterus',NULL),(0000000005,'IL-1beta','Protein','Yes','This molecule has been determined to be significantly elevated for endometriosis patients in our selected sample.','Menstrual Effluent (Blood)','Has unexplored diagnostic potential and does not require invasive surgery ','366 pg/mL','﻿10.1016/j.fertnstert.2013.09.041','Threshold','Interleukins are very broad response molecules and may not exhibit high specificy alone.','UR iGEM 2020 Team Uterus',NULL),(0000000006,'TNF-alpha','Protein','Yes','This molecule has been determined to be significantly elevated for endometriosis patients in our selected sample.','Menstrual Effluent (Blood)','Has unexplored diagnostic potential and does not require invasive surgery ','203 pg/mL','﻿10.1016/j.fertnstert.2013.09.041','Threshold','Cytokines are very broad response molecules and may not exhibit high specificy alone.','UR iGEM 2020 Team Uterus',NULL),(0000000007,'IL-8','Protein','No','This molecule has been determined to be significantly elevated for endometriosis patients in our selected sample, however there is no numerical data available.','Menstrual Effluent (Blood)','Has unexplored diagnostic potential and does not require invasive surgery ','N/A','﻿10.1016/j.fertnstert.2013.09.041','Ratio','Could not find a numerical value to set as a threshold for our diagnostic.','UR iGEM 2020 Team Uterus',NULL),(0000000008,'Uterine Natural Killler (uNK) Cells','Cell','No','Could not find a good way to obtain and test this biomarker using our selected sample.','Menstrual Effluent (Blood)','Has unexplored diagnostic potential and does not require invasive surgery ','N/A','﻿10.3389/fimmu.2017.00467','Threshold','It is difficult to specifically target uNK cells since singular unique receptors have not been identified.','UR iGEM 2020 Team Uterus',NULL),(0000000009,'CA125','Protein','No','This biomarker is not very specific to endometriosis and has not been tested in our selected sample.','Menstrual Effluent (Blood)','Has unexplored diagnostic potential and does not require invasive surgery ','N/A','﻿10.1093/humupd/1.2.173','Threshold','CA125 may add to the specficity of diagnostics in conjunction with other biomarkers, but is not specific on its own.','UR iGEM 2020 Team Uterus',NULL);
/*!40000 ALTER TABLE `Biomarker` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-10-23  0:54:15

package w.sh.admin.dao;

import w.sh.admin.model.Biomarker;
import w.sh.admin.util.JdbcUtils;

public class BiomarkerDao extends JdbcUtils<Biomarker> {

	private final String table = "Biomarker";

	public BiomarkerDao() {
		super(Biomarker.class);
		super.multiTable = table;
		super.singleTable = "Biomarker";
	}

}

package w.sh.admin.web;

import java.io.IOException;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import w.sh.admin.dao.*;

/**
 * Servlet implementation class Save
 */
@WebServlet("/save.html")
public class Save extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// Biomarker type if_project reason_project sample_type reason_sample
		// concentration DOI value_type comments contributor
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String[] fields = new String[] { "biomarker", "type", "if_project", "reason_project", "sample_type",
				"reason_sample", "concentration", "doi", "value_type", "comments", "contributor", "createdt" };
		Object[] values = new Object[] { request.getParameter("biomarker"), request.getParameter("type"),
				request.getParameter("if_project"), request.getParameter("reason_project"),
				request.getParameter("sample_type"), request.getParameter("reason_sample"),
				request.getParameter("concentration"), request.getParameter("doi"), request.getParameter("value_type"),
				request.getParameter("comments"), request.getParameter("contributor"),sdf.format(new Date())  };
		BiomarkerDao dao = new BiomarkerDao();
		try {
			dao.save(fields, values);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		response.sendRedirect("browse.html");
	}

}

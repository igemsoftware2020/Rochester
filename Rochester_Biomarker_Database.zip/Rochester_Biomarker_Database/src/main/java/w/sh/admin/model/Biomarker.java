package w.sh.admin.model;

import java.util.Date;

public class Biomarker {

	private int id;
	private String biomarker;
	private String type;
	private String if_project;
	private String reason_project;
	private String sample_type;
	private String reason_sample;
	private String concentration;
	private String doi;
	private String value_type;
	private String comments;
	private String contributor;
	private Date createdt;

	public Biomarker() {
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getBiomarker() {
		return biomarker;
	}

	public void setBiomarker(String biomarker) {
		this.biomarker = biomarker;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getIf_project() {
		return if_project;
	}

	public void setIf_project(String if_project) {
		this.if_project = if_project;
	}

	public String getReason_project() {
		return reason_project;
	}

	public void setReason_project(String reason_project) {
		this.reason_project = reason_project;
	}

	public String getSample_type() {
		return sample_type;
	}

	public void setSample_type(String sample_type) {
		this.sample_type = sample_type;
	}

	public String getReason_sample() {
		return reason_sample;
	}

	public void setReason_sample(String reason_sample) {
		this.reason_sample = reason_sample;
	}

	public String getConcentration() {
		return concentration;
	}

	public void setConcentration(String concentration) {
		this.concentration = concentration;
	}

	public String getDoi() {
		return doi;
	}

	public void setDoi(String doi) {
		this.doi = doi;
	}

	public String getValue_type() {
		return value_type;
	}

	public void setValue_type(String value_type) {
		this.value_type = value_type;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public String getContributor() {
		return contributor;
	}

	public void setContributor(String contributor) {
		this.contributor = contributor;
	}

	public Date getCreatedt() {
		return createdt;
	}

	public void setCreatedt(Date createdt) {
		this.createdt = createdt;
	}

	@Override
	public String toString() {
		return "Biomarker [id=" + id + ", biomarker=" + biomarker + ", type=" + type + ", if_project=" + if_project
				+ ", reason_project=" + reason_project + ", sample_type=" + sample_type + ", reason_sample="
				+ reason_sample + ", concentration=" + concentration + ", doi=" + doi + ", value_type=" + value_type
				+ ", comments=" + comments + ", contributor=" + contributor + ", createdt=" + createdt + "]";
	}

}

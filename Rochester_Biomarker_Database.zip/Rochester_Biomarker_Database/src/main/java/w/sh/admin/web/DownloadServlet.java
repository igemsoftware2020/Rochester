package w.sh.admin.web;

import java.io.IOException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.alibaba.excel.EasyExcel;

import w.sh.admin.dao.BiomarkerDao;
import w.sh.admin.datatables.DataTablesRequest;
import w.sh.admin.datatables.DataTablesResponse;
import w.sh.admin.model.*;

/**
 * Servlet implementation class DownloadServlet
 */
@WebServlet("/download.do")
public class DownloadServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		List<Biomarker> list = new ArrayList<>();
		BiomarkerDao dao = new BiomarkerDao();
		DataTablesRequest dtr = (DataTablesRequest) request.getSession().getAttribute("dtr");
		DataTablesResponse<Biomarker> data = dao.findAll(dtr, new String[] { "biomarker", "type", "if_project", "reason_project", "sample_type",
				"reason_sample", "concentration", "doi", "value_type", "comments", "contributor" });
		list = data.getData();
		response.setContentType("application/vnd.ms-excel");
		response.setCharacterEncoding("utf-8");
		// 这里URLEncoder.encode可以防止中文乱码 当然和easyexcel没有关系
		String fileName = URLEncoder.encode("biomarker", "UTF-8").replaceAll("\\+", "%20");
		response.setHeader("Content-disposition", "attachment;filename*=utf-8''" + fileName + ".xlsx");
		EasyExcel.write(response.getOutputStream(), Biomarker.class).sheet("biomarker").doWrite(list);
	}

}

package w.sh.admin.web;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import w.sh.admin.dao.BiomarkerDao;
import w.sh.admin.datatables.DataTablesRequest;
import w.sh.admin.datatables.DataTablesResponse;
import w.sh.admin.model.Biomarker;
import w.sh.admin.util.JsonUtils;

@WebServlet("/console/biomarker-data.do")
public class BiomarkerData extends HttpServlet {

	private static final long serialVersionUID = 2452901831637645997L;

	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		DataTablesRequest dtr = new DataTablesRequest(request);
		request.getSession().setAttribute("dtr", dtr);
		DataTablesResponse<Biomarker> pd = new BiomarkerDao().findAll(dtr,
				new String[] { "biomarker", "type", "if_project", "reason_project", "sample_type", "reason_sample",
						"concentration", "doi", "value_type", "comments", "contributor" });
		JsonUtils.printJson(response, pd);
	}

}

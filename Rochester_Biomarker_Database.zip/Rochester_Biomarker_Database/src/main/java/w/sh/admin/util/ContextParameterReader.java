package w.sh.admin.util;

import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;

import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;

/**
 * Application Lifecycle Listener implementation class Csss
 *
 */
@WebListener
public class ContextParameterReader implements ServletContextListener {

	@Override
	public void contextInitialized(ServletContextEvent sce) {
		InputStream inputStream = JdbcUtils.class.getClassLoader().getResourceAsStream(ConstantUtils.SYS_FILE);
		Properties properties = new Properties();
		try {
			properties.load(inputStream);
		} catch (IOException e) {
			e.printStackTrace();
		}

		ServletContext context = sce.getServletContext();
		context.setAttribute("systemName", properties.getProperty("systemName"));

		SimpleDateFormat sdf = new SimpleDateFormat("yyyy");
		context.setAttribute("year", sdf.format(new Date()));
	}

	@Override
	public void contextDestroyed(ServletContextEvent sce) {
		// TODO Auto-generated method stub

	}

}

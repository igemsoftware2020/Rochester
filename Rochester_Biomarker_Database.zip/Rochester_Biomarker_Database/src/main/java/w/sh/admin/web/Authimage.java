package w.sh.admin.web;

import java.io.IOException;

import javax.imageio.ImageIO;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import w.sh.admin.util.AuthCodeUtil;


/**
 * Servlet implementation class AuthimageServlet
 */
@WebServlet("/authcode.jpg")
public class Authimage extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("image/jpg");
		response.setCharacterEncoding("utf-8");
		String authCode = AuthCodeUtil.getAuthCode();
		request.getSession().setAttribute("authcode", authCode.toLowerCase());
		ImageIO.write(AuthCodeUtil.getAuthImg(authCode), "JPEG", response.getOutputStream());
	}

}

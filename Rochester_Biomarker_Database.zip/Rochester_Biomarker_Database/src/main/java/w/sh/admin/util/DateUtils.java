package w.sh.admin.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class DateUtils {

	/**
	 *
	 * @param data
	 *            类型转换为String类型<br>
	 * @param formatType
	 *            格式为yyyy-MM-dd HH:mm:ss//yyyy年MM月dd日 HH时mm分ss秒
	 * @return
	 */
	public static String dateToString(Date data, String formatType) {
		return new SimpleDateFormat(formatType).format(data);
	}

	/**
	 *
	 * @param currentTime
	 *            要转换的long类型的时间
	 * @param formatType
	 *            要转换的string类型的时间格式
	 * @return
	 * @throws ParseException
	 */
	public static String longToString(long currentTime, String formatType) throws ParseException {
		Date date = longToDate(currentTime, formatType);
		String strTime = dateToString(date, formatType);
		return strTime;
	}

	/**
	 *
	 * @param strTime
	 *            要转换的string类型的时间
	 * @param formatType
	 *            要转换的格式yyyy-MM-dd HH:mm:ss
	 * @return
	 * @throws ParseException
	 */
	public static Date stringToDate(String strTime, String formatType) throws ParseException {
		SimpleDateFormat formatter = new SimpleDateFormat(formatType);
		Date date = null;
		date = formatter.parse(strTime);
		return date;
	}

	/**
	 *
	 * @param currentTime
	 * @param formatType
	 * @return
	 * @throws ParseException
	 */
	public static Date longToDate(long currentTime, String formatType) throws ParseException {
		Date dateOld = new Date(currentTime);
		String sDateTime = dateToString(dateOld, formatType);
		Date date = stringToDate(sDateTime, formatType);
		return date;
	}

	/**
	 *
	 * @param strTime
	 * @param formatType
	 * @return
	 * @throws ParseException
	 */
	public static long stringToLong(String strTime, String formatType) throws ParseException {
		Date date = stringToDate(strTime, formatType);
		if (date == null) {
			return 0;
		} else {
			long currentTime = dateToLong(date);
			return currentTime;
		}
	}

	/**
	 *
	 * @param date
	 * @return
	 */
	public static long dateToLong(Date date) {
		return date.getTime();
	}

	/**
	 * 获取当月的第一天
	 *
	 * @return
	 */
	public static Date getFirstDayForCurrentMonth() {
		Calendar para = Calendar.getInstance(java.util.Locale.CHINA);
		para.setTime(new Date());
		para.set(Calendar.DATE, para.getActualMinimum(Calendar.DAY_OF_MONTH));
		para.set(Calendar.HOUR_OF_DAY, 0);
		para.set(Calendar.MINUTE, 0);
		para.set(Calendar.SECOND, 0);
		return para.getTime();
	}

	/**
	 * 取当前月最后一天
	 *
	 * @return
	 */
	public static Date getLastDayForCurrentMonth() {
		Calendar para = Calendar.getInstance(java.util.Locale.CHINA);
		para.setTime(new Date());
		para.set(Calendar.DATE, para.getActualMaximum(Calendar.DAY_OF_MONTH));
		para.set(Calendar.HOUR_OF_DAY, 23);
		para.set(Calendar.MINUTE, 59);
		para.set(Calendar.SECOND, 59);
		return para.getTime();
	}

	/**
	 * 获取前一个月的第一天
	 *
	 * @return
	 */
	public static Date getFirstDayForPreviousMonth() {
		Calendar para = Calendar.getInstance(java.util.Locale.CHINA);
		para.setTime(new Date());
		para.add(Calendar.MONTH, -1);
		para.set(Calendar.DATE, para.getActualMinimum(Calendar.DAY_OF_MONTH));
		para.set(Calendar.HOUR_OF_DAY, 0);
		para.set(Calendar.MINUTE, 0);
		para.set(Calendar.SECOND, 0);
		return para.getTime();
	}


	/**
	 * 获取前一个月的第一天
	 *
	 * @return
	 */
	public static Date getFirstDayForPreviousMonth(Date dt) {
		Calendar para = Calendar.getInstance(java.util.Locale.CHINA);
		para.setTime(dt);
		para.add(Calendar.MONTH, -1);
		para.set(Calendar.DATE, para.getActualMinimum(Calendar.DAY_OF_MONTH));
		para.set(Calendar.HOUR_OF_DAY, 0);
		para.set(Calendar.MINUTE, 0);
		para.set(Calendar.SECOND, 0);
		return para.getTime();
	}

	/**
	 * 取前一个月最后一天
	 *
	 * @return
	 */
	public static Date getLastDayForPreviousMonth() {
		Calendar para = Calendar.getInstance(java.util.Locale.CHINA);
		para.setTime(new Date());
		para.add(Calendar.MONTH, -1);
		para.set(Calendar.DATE, para.getActualMaximum(Calendar.DAY_OF_MONTH));
		para.set(Calendar.HOUR_OF_DAY, 23);
		para.set(Calendar.MINUTE, 59);
		para.set(Calendar.SECOND, 59);
		return para.getTime();
	}

	/**
	 * 今年第一天
	 *
	 * @return
	 */
	public static Date getFirstDayForCurrentYear() {
		Date result = null;
		Calendar cale = null;
		cale = Calendar.getInstance();
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		String firstday;
		cale = Calendar.getInstance();
		cale.add(Calendar.YEAR, 0);
		cale.set(Calendar.MONTH, 0);
		cale.set(Calendar.DAY_OF_MONTH, 1);
		firstday = format.format(cale.getTime());
		try {
			result = stringToDate(firstday, "yyyy-MM-dd");
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return result;
	}

	/**
	 * 今年最后一天
	 *
	 * @return
	 */
	public static Date getLastDayForCurrentYear() {
		Date result = null;
		Calendar cale = null;
		cale = Calendar.getInstance();
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		String lastday;
		cale = Calendar.getInstance();
		cale.add(Calendar.YEAR, 0);
		cale.set(Calendar.MONTH, 12);
		cale.set(Calendar.DAY_OF_MONTH, 0);
		lastday = format.format(cale.getTime());
		try {
			result = stringToDate(lastday, "yyyy-MM-dd");
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return result;
	}

	/**
	 * 去年第一天
	 *
	 * @return
	 */
	public static Date getFirstDayForPreviousYear() {
		Date result = null;
		Calendar cale = null;
		cale = Calendar.getInstance();
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		String firstday;
		cale = Calendar.getInstance();
		cale.add(Calendar.YEAR, -1);
		cale.set(Calendar.MONTH, 0);
		cale.set(Calendar.DAY_OF_MONTH, 1);
		firstday = format.format(cale.getTime());
		try {
			result = stringToDate(firstday, "yyyy-MM-dd");
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return result;
	}

	/**
	 * 去年最后一天
	 *
	 * @return
	 */
	public static Date getLastDayForPreviousYear() {
		Date result = null;
		Calendar cale = null;
		cale = Calendar.getInstance();
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		String lastday;
		cale = Calendar.getInstance();
		cale.add(Calendar.YEAR, -1);
		cale.set(Calendar.MONTH, 12);
		cale.set(Calendar.DAY_OF_MONTH, 0);
		lastday = format.format(cale.getTime());
		try {
			result = stringToDate(lastday, "yyyy-MM-dd");
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return result;
	}

	/**
	 * 第一天
	 *
	 * @param year
	 * @param month
	 * @return
	 */
	public static Date getFirstDay(int year, int month) {
		Calendar para = Calendar.getInstance(java.util.Locale.CHINA);
		para.setTime(new Date());
		para.set(Calendar.YEAR, year);
		para.set(Calendar.MONTH, month - 1);
		para.set(Calendar.DATE, para.getActualMinimum(Calendar.DAY_OF_MONTH));
		para.set(Calendar.HOUR_OF_DAY, 0);
		para.set(Calendar.MINUTE, 0);
		para.set(Calendar.SECOND, 0);
		return para.getTime();
	}

	/**
	 * 最后一天
	 *
	 * @param year
	 * @param month
	 * @return
	 */
	public static Date getLastDay(int year, int month) {

		Calendar para = Calendar.getInstance(java.util.Locale.CHINA);
		para.setTime(new Date());
		para.set(Calendar.YEAR, year);
		para.set(Calendar.MONTH, month - 1);
		para.set(Calendar.DATE, para.getActualMaximum(Calendar.DAY_OF_MONTH));
		para.set(Calendar.HOUR_OF_DAY, 23);
		para.set(Calendar.MINUTE, 59);
		para.set(Calendar.SECOND, 59);

		return para.getTime();
	}
}

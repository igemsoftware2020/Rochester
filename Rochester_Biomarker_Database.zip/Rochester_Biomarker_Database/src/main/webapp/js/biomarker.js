function loadDataByList() {
    var table = $('#example').DataTable({
        language: {url: 'static/datatables/1.10.19/js/Chinese.json'},
        processing: true,
        serverSide: true,
        paging: true,//开启分页
        searching: true,
        order: [[1, "asc"]],
        ajax: {
            url: "console/biomarker-data.do",
            data: function (data) {
                //console.log(data);
            }
        },
        columns: [{data: 'biomarker', width: '50px'},
            {data: 'type'},
            {data: 'sample_type'},
 			{data: 'concentration'},
 			{data: 'value_type'},
			{data: 'contributor'}
			],
        autoWidth: false

    });
}

$('#search').bind('keypress', function(event) {
	if (event.keyCode == "13") {
		alert('你输入的内容为：' + $('#search').val());
	}
});


